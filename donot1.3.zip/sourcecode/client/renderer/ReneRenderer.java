
package net.mcreator.donotbeta.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.donotbeta.entity.ReneEntity;
import net.mcreator.donotbeta.client.model.ModelPigEntityModel;

public class ReneRenderer extends MobRenderer<ReneEntity, ModelPigEntityModel<ReneEntity>> {
	public ReneRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelPigEntityModel(context.bakeLayer(ModelPigEntityModel.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ReneEntity entity) {
		return new ResourceLocation("do_not_beta:textures/entities/pig_1.png");
	}
}
