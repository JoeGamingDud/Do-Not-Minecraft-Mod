
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.donotbeta.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.donotbeta.block.PoopworldPortalBlock;
import net.mcreator.donotbeta.block.PoopieBlock;
import net.mcreator.donotbeta.block.PissFragmentsBlock;
import net.mcreator.donotbeta.block.PissDimensionPortalBlock;
import net.mcreator.donotbeta.block.PissBLockBlock;
import net.mcreator.donotbeta.block.FrozenPissBlock;
import net.mcreator.donotbeta.block.ComposedPoopieBlock;
import net.mcreator.donotbeta.DoNotBetaMod;

public class DoNotBetaModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, DoNotBetaMod.MODID);
	public static final RegistryObject<Block> POOPIE = REGISTRY.register("poopie", () -> new PoopieBlock());
	public static final RegistryObject<Block> POOPWORLD_PORTAL = REGISTRY.register("poopworld_portal", () -> new PoopworldPortalBlock());
	public static final RegistryObject<Block> COMPOSED_POOPIE = REGISTRY.register("composed_poopie", () -> new ComposedPoopieBlock());
	public static final RegistryObject<Block> PISS_FRAGMENTS = REGISTRY.register("piss_fragments", () -> new PissFragmentsBlock());
	public static final RegistryObject<Block> PISS_B_LOCK = REGISTRY.register("piss_b_lock", () -> new PissBLockBlock());
	public static final RegistryObject<Block> FROZEN_PISS = REGISTRY.register("frozen_piss", () -> new FrozenPissBlock());
	public static final RegistryObject<Block> PISS_DIMENSION_PORTAL = REGISTRY.register("piss_dimension_portal", () -> new PissDimensionPortalBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			PoopieBlock.blockColorLoad(event);
			PissFragmentsBlock.blockColorLoad(event);
			PissBLockBlock.blockColorLoad(event);
			FrozenPissBlock.blockColorLoad(event);
		}
	}
}
