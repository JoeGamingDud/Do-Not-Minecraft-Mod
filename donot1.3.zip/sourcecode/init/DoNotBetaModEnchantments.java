
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.donotbeta.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.donotbeta.enchantment.PoPoPePeEnchantmentEnchantment;
import net.mcreator.donotbeta.DoNotBetaMod;

public class DoNotBetaModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, DoNotBetaMod.MODID);
	public static final RegistryObject<Enchantment> PO_PO_PE_PE_ENCHANTMENT = REGISTRY.register("po_po_pe_pe_enchantment", () -> new PoPoPePeEnchantmentEnchantment());
}
