
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.donotbeta.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.donotbeta.entity.ReneEntity;
import net.mcreator.donotbeta.entity.PissMonsterEntity;
import net.mcreator.donotbeta.DoNotBetaMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class DoNotBetaModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DoNotBetaMod.MODID);
	public static final RegistryObject<EntityType<ReneEntity>> RENE = register("rene",
			EntityType.Builder.<ReneEntity>of(ReneEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(67).setUpdateInterval(3).setCustomClientFactory(ReneEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<PissMonsterEntity>> PISS_MONSTER = register("piss_monster", EntityType.Builder.<PissMonsterEntity>of(PissMonsterEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(66).setUpdateInterval(3).setCustomClientFactory(PissMonsterEntity::new).fireImmune().sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			ReneEntity.init();
			PissMonsterEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(RENE.get(), ReneEntity.createAttributes().build());
		event.put(PISS_MONSTER.get(), PissMonsterEntity.createAttributes().build());
	}
}
