
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.donotbeta.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.donotbeta.item.PopoItem;
import net.mcreator.donotbeta.item.PoopworldItem;
import net.mcreator.donotbeta.item.PoopWaterItem;
import net.mcreator.donotbeta.item.PoopSwordItem;
import net.mcreator.donotbeta.item.PoopSockItem;
import net.mcreator.donotbeta.item.PoopItem;
import net.mcreator.donotbeta.item.PoopBowItem;
import net.mcreator.donotbeta.item.PissDimensionItem;
import net.mcreator.donotbeta.DoNotBetaMod;

public class DoNotBetaModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, DoNotBetaMod.MODID);
	public static final RegistryObject<Item> POOP = REGISTRY.register("poop", () -> new PoopItem());
	public static final RegistryObject<Item> POPO_HELMET = REGISTRY.register("popo_helmet", () -> new PopoItem.Helmet());
	public static final RegistryObject<Item> POPO_CHESTPLATE = REGISTRY.register("popo_chestplate", () -> new PopoItem.Chestplate());
	public static final RegistryObject<Item> POPO_LEGGINGS = REGISTRY.register("popo_leggings", () -> new PopoItem.Leggings());
	public static final RegistryObject<Item> POPO_BOOTS = REGISTRY.register("popo_boots", () -> new PopoItem.Boots());
	public static final RegistryObject<Item> POOPIE = block(DoNotBetaModBlocks.POOPIE);
	public static final RegistryObject<Item> POOPWORLD = REGISTRY.register("poopworld", () -> new PoopworldItem());
	public static final RegistryObject<Item> COMPOSED_POOPIE = block(DoNotBetaModBlocks.COMPOSED_POOPIE);
	public static final RegistryObject<Item> PISS_FRAGMENTS = block(DoNotBetaModBlocks.PISS_FRAGMENTS);
	public static final RegistryObject<Item> POOP_SWORD = REGISTRY.register("poop_sword", () -> new PoopSwordItem());
	public static final RegistryObject<Item> POOP_BOW = REGISTRY.register("poop_bow", () -> new PoopBowItem());
	public static final RegistryObject<Item> PISS_B_LOCK = block(DoNotBetaModBlocks.PISS_B_LOCK);
	public static final RegistryObject<Item> FROZEN_PISS = block(DoNotBetaModBlocks.FROZEN_PISS);
	public static final RegistryObject<Item> PISS_DIMENSION = REGISTRY.register("piss_dimension", () -> new PissDimensionItem());
	public static final RegistryObject<Item> RENE_SPAWN_EGG = REGISTRY.register("rene_spawn_egg", () -> new ForgeSpawnEggItem(DoNotBetaModEntities.RENE, -12768509, -16777216, new Item.Properties()));
	public static final RegistryObject<Item> POOP_SOCK = REGISTRY.register("poop_sock", () -> new PoopSockItem());
	public static final RegistryObject<Item> PISS_MONSTER_SPAWN_EGG = REGISTRY.register("piss_monster_spawn_egg", () -> new ForgeSpawnEggItem(DoNotBetaModEntities.PISS_MONSTER, -2151, -16777216, new Item.Properties()));
	public static final RegistryObject<Item> POOP_WATER = REGISTRY.register("poop_water", () -> new PoopWaterItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
