
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.donotbeta.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.donotbeta.client.model.ModelPissEntityModel;
import net.mcreator.donotbeta.client.model.ModelPigEntityModel;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class DoNotBetaModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelPissEntityModel.LAYER_LOCATION, ModelPissEntityModel::createBodyLayer);
		event.registerLayerDefinition(ModelPigEntityModel.LAYER_LOCATION, ModelPigEntityModel::createBodyLayer);
	}
}
