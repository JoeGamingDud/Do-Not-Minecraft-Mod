
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.donotbeta.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.donotbeta.DoNotBetaMod;

public class DoNotBetaModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, DoNotBetaMod.MODID);
	public static final RegistryObject<SoundEvent> FART = REGISTRY.register("fart", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("do_not_beta", "fart")));
	public static final RegistryObject<SoundEvent> POOPWORLD = REGISTRY.register("poopworld", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("do_not_beta", "poopworld")));
	public static final RegistryObject<SoundEvent> SPECIALBOY = REGISTRY.register("specialboy", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("do_not_beta", "specialboy")));
}
