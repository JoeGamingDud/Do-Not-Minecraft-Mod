
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.donotbeta.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.donotbeta.DoNotBetaMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class DoNotBetaModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DoNotBetaMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {

		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(DoNotBetaModBlocks.POOPIE.get().asItem());
		}

		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(DoNotBetaModItems.POPO_HELMET.get());
			tabData.accept(DoNotBetaModItems.POPO_CHESTPLATE.get());
			tabData.accept(DoNotBetaModItems.POPO_LEGGINGS.get());
			tabData.accept(DoNotBetaModItems.POPO_BOOTS.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(DoNotBetaModItems.RENE_SPAWN_EGG.get());
			tabData.accept(DoNotBetaModItems.PISS_MONSTER_SPAWN_EGG.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(DoNotBetaModItems.POOP.get());
			tabData.accept(DoNotBetaModItems.POOP_SOCK.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(DoNotBetaModItems.POOPWORLD.get());
			tabData.accept(DoNotBetaModItems.POOP_SWORD.get());
			tabData.accept(DoNotBetaModItems.POOP_BOW.get());
			tabData.accept(DoNotBetaModItems.PISS_DIMENSION.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(DoNotBetaModBlocks.COMPOSED_POOPIE.get().asItem());
			tabData.accept(DoNotBetaModBlocks.PISS_B_LOCK.get().asItem());
			tabData.accept(DoNotBetaModBlocks.FROZEN_PISS.get().asItem());
		}

		if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(DoNotBetaModBlocks.PISS_FRAGMENTS.get().asItem());
			tabData.accept(DoNotBetaModItems.POOP_WATER.get());
		}
	}
}
